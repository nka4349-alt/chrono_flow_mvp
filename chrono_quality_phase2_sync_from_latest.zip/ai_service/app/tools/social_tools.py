from __future__ import annotations

from typing import Any, Dict, List, Optional
import unicodedata


SOCIAL_HINTS = [
    "友達", "友人", "遊び", "遊ぶ", "遊びに行く", "出かけ", "出掛け", "お出かけ", "おでかけ",
    "旅行", "ドライブ", "会う", "会いたい", "ご飯", "ごはん", "食事", "ランチ", "ディナー", "飲み",
    "カフェ", "映画", "買い物", "散歩",
]
NAME_SUFFIXES = ("さん", "ちゃん", "くん", "氏", "先生", "先輩", "殿")


def normalize_text(text: str) -> str:
    return unicodedata.normalize("NFKC", (text or "")).strip().lower()


def normalize_name(text: str) -> str:
    value = normalize_text(text).replace(" ", "").replace("　", "")
    changed = True
    while changed:
        changed = False
        for suffix in NAME_SUFFIXES:
            suffix_norm = normalize_text(suffix)
            if value.endswith(suffix_norm) and len(value) > len(suffix_norm):
                value = value[: -len(suffix_norm)]
                changed = True
                break
    return value


def _contact_rows(context: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for contact in context.get("contacts") or []:
        if isinstance(contact, dict) and (contact.get("display_name") or "").strip():
            rows.append(contact)
    return rows


def _friend_rows(context: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for friend in context.get("friends") or []:
        if isinstance(friend, dict) and (friend.get("name") or friend.get("display_name") or "").strip():
            rows.append(friend)
    return rows


def _recent_peer_rows(context: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    seen = set()
    for message in context.get("recent_direct_messages") or []:
        if not isinstance(message, dict):
            continue
        peer_name = (message.get("peer_name") or "").strip()
        if not peer_name:
            continue
        key = normalize_name(peer_name)
        if not key or key in seen:
            continue
        seen.add(key)
        rows.append(
            {
                "id": message.get("peer_id"),
                "name": peer_name,
                "timezone": message.get("timezone") or "Asia/Tokyo",
                "source": "recent_direct_messages",
            }
        )
    return rows


def _make_pseudo_contact(friend: Dict[str, Any], source: str = "friend_list") -> Dict[str, Any]:
    display_name = (friend.get("name") or friend.get("display_name") or "").strip()
    return {
        "id": friend.get("id"),
        "display_name": display_name,
        "relation_type": "friend",
        "timezone": friend.get("timezone") or "Asia/Tokyo",
        "preferred_duration_minutes": 90,
        "availability_profiles": [],
        "linked_user_id": friend.get("id"),
        "email": friend.get("email"),
        "source": source,
    }


def _candidate_entries(context: Dict[str, Any]) -> List[Dict[str, Any]]:
    entries: List[Dict[str, Any]] = []
    seen = set()

    for contact in _contact_rows(context):
        name = (contact.get("display_name") or "").strip()
        aliases = {normalize_text(name), normalize_name(name)} - {""}
        key = ("contact", normalize_name(name))
        if key in seen:
            continue
        seen.add(key)
        entries.append({"source": "contacts", "name": name, "aliases": aliases, "contact": contact, "priority": 30})

    for friend in _friend_rows(context):
        pseudo = _make_pseudo_contact(friend, source="friend_list")
        name = pseudo.get("display_name") or ""
        aliases = {normalize_text(name), normalize_name(name)} - {""}
        key = ("friend", normalize_name(name))
        if key in seen:
            continue
        seen.add(key)
        entries.append({"source": "friends", "name": name, "aliases": aliases, "contact": pseudo, "priority": 20})

    for peer in _recent_peer_rows(context):
        pseudo = _make_pseudo_contact(peer, source="recent_direct_messages")
        name = pseudo.get("display_name") or ""
        aliases = {normalize_text(name), normalize_name(name)} - {""}
        key = ("peer", normalize_name(name))
        if key in seen:
            continue
        seen.add(key)
        entries.append({"source": "recent_direct_messages", "name": name, "aliases": aliases, "contact": pseudo, "priority": 10})

    return entries


def resolve_entities(text: str, context: Dict[str, Any], planned_contact_name: Optional[str] = None) -> Dict[str, Any]:
    normalized = normalize_text(text)
    compact_message = normalize_name(text)
    planned_name = normalize_name(planned_contact_name or "")

    best_entry = None
    best_score = -1

    for entry in _candidate_entries(context):
        score = -1
        for alias in entry.get("aliases") or []:
            if not alias:
                continue
            if planned_name and alias == planned_name:
                score = max(score, 120 + entry["priority"])
            elif planned_name and (planned_name in alias or alias in planned_name):
                score = max(score, 90 + entry["priority"])

            if alias and alias in compact_message:
                score = max(score, 100 + entry["priority"] + min(len(alias), 12))
            elif alias and alias in normalized:
                score = max(score, 95 + entry["priority"] + min(len(alias), 12))

        if score > best_score:
            best_entry = entry
            best_score = score

    resolved_contact = best_entry.get("contact") if best_entry and best_score >= 0 else None
    resolved_name = (resolved_contact or {}).get("display_name") if resolved_contact else None
    social_signal = any(token in normalized for token in [normalize_text(value) for value in SOCIAL_HINTS])

    candidate_names = []
    for entry in _candidate_entries(context)[:16]:
        if entry.get("name"):
            candidate_names.append(entry["name"])

    return {
        "resolved_contact": resolved_contact,
        "resolved_contact_name": resolved_name,
        "matched_from": best_entry.get("source") if best_entry and resolved_contact else None,
        "social_signal": social_signal or bool(resolved_contact),
        "friend_candidates": candidate_names,
    }
