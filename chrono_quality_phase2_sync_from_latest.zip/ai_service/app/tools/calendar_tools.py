from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
import re
import unicodedata


TIME_LABEL_RANGES = {
    "morning": (8 * 60, 12 * 60),
    "lunch": (11 * 60, 14 * 60),
    "afternoon": (13 * 60, 18 * 60),
    "evening": (17 * 60, 20 * 60),
    "after_work": (18 * 60, 21 * 60),
    "night": (19 * 60, 22 * 60),
}
TIME_TOKEN_LABELS = {
    "morning": ["朝", "朝イチ", "午前", "午前中"],
    "lunch": ["昼", "お昼", "ランチ"],
    "afternoon": ["午後", "午後中"],
    "evening": ["夕方", "放課後"],
    "after_work": ["仕事終わり", "退勤後", "終業後"],
    "night": ["夜", "今夜", "晩", "ディナー"],
}
TIME_ANCHOR_RE = re.compile(r"(?:(午前|午後))?\s*(\d{1,2})\s*時(?!間)(?:\s*(\d{1,2})\s*分)?\s*(以降|から|頃|ごろ|まで)?")


def normalize_text(text: str) -> str:
    return unicodedata.normalize("NFKC", (text or "")).strip().lower()


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _append_range(ranges: List[Dict[str, int]], start_minute: int, end_minute: int) -> None:
    start = max(0, min(24 * 60, int(start_minute)))
    end = max(0, min(24 * 60, int(end_minute)))
    if end <= start:
        return
    candidate = {"start_minute": start, "end_minute": end}
    if candidate not in ranges:
        ranges.append(candidate)


def extract_date_constraints(now: datetime, planned_day_offsets: List[int], planned_strict_day: bool) -> Dict[str, Any]:
    offsets: List[int] = []
    for value in planned_day_offsets or []:
        try:
            offset = int(value)
        except Exception:
            continue
        if 0 <= offset <= 21 and offset not in offsets:
            offsets.append(offset)

    target_dates = [
        (now + timedelta(days=offset)).date().isoformat()
        for offset in offsets[:7]
    ]

    return {
        "day_offsets": offsets[:7],
        "strict_day": bool(planned_strict_day),
        "target_dates": target_dates,
    }


def summarize_calendar(context: Dict[str, Any], now: datetime, day_offsets: List[int], strict_day: bool, limit_days: int = 4) -> Dict[str, Any]:
    events = [event for event in (context.get("personal_events") or []) if isinstance(event, dict)]
    normalized_offsets = []
    for value in day_offsets or []:
        try:
            offset = int(value)
        except Exception:
            continue
        if 0 <= offset <= 21 and offset not in normalized_offsets:
            normalized_offsets.append(offset)

    if not normalized_offsets:
        normalized_offsets = list(range(0, limit_days))

    days: List[Dict[str, Any]] = []
    for offset in normalized_offsets[:limit_days]:
        day_start = (now + timedelta(days=offset)).replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_start + timedelta(days=1)
        busy_minutes = 0
        matches: List[Dict[str, Any]] = []
        for event in events:
            start_at = _parse_iso(event.get("start_at"))
            end_at = _parse_iso(event.get("end_at"))
            if not start_at or not end_at:
                continue
            if end_at <= day_start or start_at >= day_end:
                continue
            clipped_start = max(start_at, day_start)
            clipped_end = min(end_at, day_end)
            busy_minutes += max(0, int((clipped_end - clipped_start).total_seconds() // 60))
            matches.append(
                {
                    "title": event.get("title"),
                    "start_at": start_at.isoformat(),
                    "end_at": end_at.isoformat(),
                    "all_day": bool(event.get("all_day")),
                }
            )

        days.append(
            {
                "offset": offset,
                "date": day_start.date().isoformat(),
                "event_count": len(matches),
                "busy_minutes": busy_minutes,
                "events": matches[:6],
            }
        )

    total_busy = sum(_safe_int(day.get("busy_minutes")) for day in days)
    return {
        "strict_day": bool(strict_day),
        "evaluated_days": days,
        "total_busy_minutes": total_busy,
    }


def extract_time_preferences(text: str, planned_profile: Optional[str] = None) -> Dict[str, Any]:
    normalized = normalize_text(text)
    labels: List[str] = []
    ranges: List[Dict[str, int]] = []
    strict = False

    if normalized:
        for label, tokens in TIME_TOKEN_LABELS.items():
            if any(token in normalized for token in tokens):
                labels.append(label)
                start_minute, end_minute = TIME_LABEL_RANGES[label]
                _append_range(ranges, start_minute, end_minute)
                strict = True

        for match in TIME_ANCHOR_RE.finditer(normalized):
            meridiem = match.group(1)
            hour = int(match.group(2))
            minute = int(match.group(3) or 0)
            qualifier = match.group(4) or ""

            if meridiem == "午後" and hour < 12:
                hour += 12
            if meridiem == "午前" and hour == 12:
                hour = 0

            anchor = max(0, min(24 * 60, hour * 60 + minute))
            strict = True
            if qualifier in {"以降", "から"}:
                _append_range(ranges, anchor, min(anchor + 4 * 60, 24 * 60))
            elif qualifier == "まで":
                _append_range(ranges, max(anchor - 4 * 60, 0), anchor)
            else:
                _append_range(ranges, max(anchor - 60, 0), min(anchor + 120, 24 * 60))

    if not labels and planned_profile == "social" and normalized and any(token in normalized for token in ["飲み", "ディナー", "ご飯"]):
        labels.append("evening")
        _append_range(ranges, *TIME_LABEL_RANGES["evening"])

    return {
        "labels": labels,
        "ranges": sorted(ranges, key=lambda item: (item["start_minute"], item["end_minute"])),
        "strict": bool(strict),
    }
