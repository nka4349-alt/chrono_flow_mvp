from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
import json
import re
import unicodedata

from .llm_backend import CONFIG, generate_json, health_status


ALLOWED_INTENTS = {
    "meeting",
    "alignment",
    "review",
    "approval",
    "kickoff",
    "friend_meetup",
    "family_plan",
    "follow_up",
    "general",
}
ALLOWED_CATEGORIES = {"work", "friend", "family", "group", "other"}
ALLOWED_PROFILES = {"work", "social", "family", "group"}
WEEKDAY_MAP = {
    "月": 0,
    "月曜": 0,
    "月曜日": 0,
    "火": 1,
    "火曜": 1,
    "火曜日": 1,
    "水": 2,
    "水曜": 2,
    "水曜日": 2,
    "木": 3,
    "木曜": 3,
    "木曜日": 3,
    "金": 4,
    "金曜": 4,
    "金曜日": 4,
    "土": 5,
    "土曜": 5,
    "土曜日": 5,
    "日": 6,
    "日曜": 6,
    "日曜日": 6,
}
NAME_SUFFIXES = ("さん", "ちゃん", "くん", "氏", "先生", "先輩", "殿")
WORK_CUES = ["会議", "ミーティング", "meeting", "mtg", "打ち合わせ", "打合せ", "レビュー", "相談", "調整", "合議", "稟議", "キックオフ", "定例", "1on1", "面談", "商談"]
FAMILY_CUES = ["家族", "親", "母", "父", "子ども", "子供", "実家", "通院", "送り迎え", "付き添い"]
SOCIAL_CUES = ["友達", "友人", "遊び", "遊ぶ", "遊びに行く", "出かけ", "お出かけ", "旅行", "ドライブ", "会う", "会いたい", "ご飯", "ごはん", "食事", "ランチ", "ディナー", "飲み", "カフェ", "映画", "買い物", "散歩"]
INTENT_DEFAULTS = {
    "meeting": {"category": "work", "profile": "work", "duration_minutes": 45},
    "alignment": {"category": "work", "profile": "work", "duration_minutes": 30},
    "review": {"category": "work", "profile": "work", "duration_minutes": 45},
    "approval": {"category": "work", "profile": "work", "duration_minutes": 45},
    "kickoff": {"category": "work", "profile": "work", "duration_minutes": 60},
    "follow_up": {"category": "work", "profile": "work", "duration_minutes": 30},
    "friend_meetup": {"category": "friend", "profile": "social", "duration_minutes": 90},
    "family_plan": {"category": "family", "profile": "family", "duration_minutes": 90},
    "general": {"category": "other", "profile": "work", "duration_minutes": 60},
}


_DURATION_MINUTES_RE = re.compile(r"(?P<num>\d{1,2})\s*分")
_DURATION_HOURS_HALF_RE = re.compile(r"(?P<num>\d{1,2})\s*時間\s*半")
_DURATION_HOURS_RE = re.compile(r"(?P<num>\d{1,2})\s*時間(?:\s*(?P<minutes>\d{1,2})\s*分)?")


def normalize_text(text: str) -> str:
    return unicodedata.normalize("NFKC", (text or "")).strip().lower()


def compact_name(name: str) -> str:
    value = normalize_text(name).replace(" ", "").replace("　", "")
    changed = True
    while changed:
        changed = False
        for suffix in NAME_SUFFIXES:
            suffix_norm = normalize_text(suffix)
            if value.endswith(suffix_norm) and len(value) > len(suffix_norm):
                value = value[: -len(suffix_norm)]
                changed = True
                break
    return value


def compact_events(events: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for event in (events or [])[:limit]:
        if not isinstance(event, dict):
            continue
        rows.append(
            {
                "title": event.get("title"),
                "start_at": event.get("start_at"),
                "end_at": event.get("end_at"),
                "group_names": event.get("group_names") or [],
                "all_day": bool(event.get("all_day")),
            }
        )
    return rows


def compact_contacts(context: Dict[str, Any], limit: int = 12) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for contact in (context.get("contacts") or [])[:limit]:
        if not isinstance(contact, dict):
            continue
        name = (contact.get("display_name") or "").strip()
        if not name:
            continue
        rows.append(
            {
                "id": contact.get("id"),
                "display_name": name,
                "relation_type": contact.get("relation_type"),
                "timezone": contact.get("timezone"),
                "preferred_duration_minutes": contact.get("preferred_duration_minutes"),
            }
        )
    return rows


def compact_friends(context: Dict[str, Any], limit: int = 12) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for friend in (context.get("friends") or [])[:limit]:
        if not isinstance(friend, dict):
            continue
        name = (friend.get("name") or friend.get("display_name") or "").strip()
        if not name:
            continue
        rows.append(
            {
                "id": friend.get("id"),
                "name": name,
                "timezone": friend.get("timezone"),
                "email": friend.get("email"),
            }
        )
    return rows


def compact_recent_messages(context: Dict[str, Any], scope: str, limit: int = 6) -> List[Dict[str, Any]]:
    if scope == "group":
        source = context.get("recent_group_messages") or []
        rows = []
        for message in source[-limit:]:
            if not isinstance(message, dict):
                continue
            rows.append(
                {
                    "author": message.get("author_name") or message.get("author"),
                    "body": message.get("body"),
                    "created_at": message.get("created_at"),
                }
            )
        return rows

    source = context.get("ai_recent_messages") or []
    rows = []
    for message in source[-limit:]:
        if not isinstance(message, dict):
            continue
        rows.append(
            {
                "role": message.get("role"),
                "body": message.get("body"),
                "created_at": message.get("created_at"),
            }
        )
    return rows


def compact_recent_direct_messages(context: Dict[str, Any], limit: int = 8) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for message in (context.get("recent_direct_messages") or [])[-limit:]:
        if not isinstance(message, dict):
            continue
        rows.append(
            {
                "peer_name": message.get("peer_name"),
                "user_name": message.get("user_name"),
                "body": message.get("body"),
                "created_at": message.get("created_at"),
            }
        )
    return rows


def planner_context_summary(scope: str, user_message: str, context: Dict[str, Any]) -> str:
    payload = {
        "scope": scope,
        "timezone": context.get("timezone") or "Asia/Tokyo",
        "now": context.get("now"),
        "user_message": user_message,
        "group": {
            "id": (context.get("group") or {}).get("id"),
            "name": (context.get("group") or {}).get("name"),
        }
        if scope == "group"
        else None,
        "personal_events": compact_events(context.get("personal_events") or [], limit=10),
        "candidate_group_events": compact_events(context.get("candidate_group_events") or [], limit=8),
        "contacts": compact_contacts(context, limit=12),
        "friends": compact_friends(context, limit=12),
        "recent_direct_messages": compact_recent_direct_messages(context, limit=8),
        "recent_messages": compact_recent_messages(context, scope=scope),
    }
    return json.dumps(payload, ensure_ascii=False)


def _collect_offsets(now: datetime, predicate, start: int = 0, horizon: int = 21, limit: int = 7) -> List[int]:
    return [offset for offset in range(start, horizon + 1) if predicate(now + timedelta(days=offset))][:limit]


def explicit_day_offsets_from_text(text: str, now: datetime) -> Tuple[Optional[List[int]], bool]:
    normalized = normalize_text(text)
    if not normalized:
        return None, False

    if "明々後日" in normalized or "しあさって" in normalized:
        return [3], True
    if "明後日" in normalized or "あさって" in normalized:
        return [2], True
    if "明日" in normalized or "あした" in normalized:
        return [1], True
    if "今日" in normalized or "きょう" in normalized:
        return [0], True

    if "今週中" in normalized:
        offsets = _collect_offsets(now, lambda d: d.weekday() <= 6 and d.isoweekday() <= 7, start=0, horizon=max(0, 6 - now.weekday()), limit=7)
        return offsets or [0], True

    if "来週前半" in normalized:
        offsets = _collect_offsets(now, lambda d: 0 <= d.weekday() <= 2, start=7, horizon=13, limit=4)
        return offsets or [7, 8, 9], True

    if "来週後半" in normalized:
        offsets = _collect_offsets(now, lambda d: 3 <= d.weekday() <= 6, start=7, horizon=13, limit=4)
        return offsets or [10, 11, 12, 13], True

    if "来週末" in normalized or "次の週末" in normalized:
        offsets = _collect_offsets(now, lambda d: d.weekday() >= 5, start=7, horizon=20, limit=4)
        return offsets or [12, 13], True

    if "平日" in normalized:
        offsets = _collect_offsets(now, lambda d: d.weekday() < 5, start=0, horizon=14, limit=7)
        return offsets or [0], True

    if "今週末" in normalized or "週末" in normalized or "土日" in normalized:
        offsets = _collect_offsets(now, lambda d: d.weekday() >= 5, start=0, horizon=13, limit=4)
        return offsets[:4] or [5], True

    matched_weekday = None
    for token, weekday in WEEKDAY_MAP.items():
        if token in normalized:
            matched_weekday = weekday
            break

    if matched_weekday is None:
        return None, False

    if "再来週" in normalized:
        offsets = _collect_offsets(now, lambda d: d.weekday() == matched_weekday, start=14, horizon=20, limit=1)
        return offsets or [14], True
    if "来週" in normalized:
        offsets = _collect_offsets(now, lambda d: d.weekday() == matched_weekday, start=7, horizon=13, limit=1)
        return offsets or [7], True
    if "今週" in normalized:
        offsets = _collect_offsets(now, lambda d: d.weekday() == matched_weekday, start=0, horizon=max(0, 6 - now.weekday()), limit=1)
        return offsets or [0], True

    delta = (matched_weekday - now.weekday()) % 7
    return [delta], True


def explicit_duration_minutes_from_text(text: str) -> Optional[int]:
    normalized = normalize_text(text)
    if not normalized:
        return None

    match = _DURATION_HOURS_HALF_RE.search(normalized)
    if match:
        value = int(match.group("num")) * 60 + 30
        return value if 15 <= value <= 240 else None

    match = _DURATION_HOURS_RE.search(normalized)
    if match:
        hours = int(match.group("num"))
        minutes = int(match.group("minutes") or 0)
        value = hours * 60 + minutes
        return value if 15 <= value <= 240 else None

    match = _DURATION_MINUTES_RE.search(normalized)
    if match:
        value = int(match.group("num"))
        return value if 15 <= value <= 240 else None

    return None


def _system_prompt() -> str:
    return (
        "You are a planning model for ChronoFlow. "
        "Return one JSON object only. No markdown, no prose. "
        "Interpret Japanese scheduling requests into a structured plan. "
        "Prefer work/business intent when the user mentions meetings, reviews, kickoff, alignment, approval, or scheduling in free time, "
        "unless the user explicitly mentions family/friends/contact names or clear social words. "
        "Use friends, contacts, recent direct messages, and recent chat history from the provided context to infer likely people names. "
        "Resolve relative dates against the provided now/tz. "
        "For explicit date words like 今日/明日/明後日/来週火曜/来週末, set strict_day=true and day_offsets accordingly. "
        "When the user did not specify a date, leave day_offsets empty. "
        "If the user specifies duration such as 30分/1時間/1時間半, return duration_minutes. "
        "Allowed intent values: meeting, alignment, review, approval, kickoff, friend_meetup, family_plan, follow_up, general. "
        "Allowed category values: work, friend, family, group, other. "
        "Allowed profile values: work, social, family, group. "
        "Keys: intent, category, profile, duration_minutes, day_offsets, strict_day, contact_name, assistant_message, confidence."
    )


def _user_prompt(scope: str, user_message: str, context: Dict[str, Any]) -> str:
    return (
        "Use the following JSON context.\n"
        "Return JSON only. Example:\n"
        '{"intent":"meeting","category":"work","profile":"work","duration_minutes":45,'
        '"day_offsets":[2],"strict_day":true,"contact_name":null,'
        '"assistant_message":"明後日に会議を入れやすい空き時間を優先して候補を出します。",'
        '"confidence":0.92}\n\n'
        f"context_json:\n{planner_context_summary(scope, user_message, context)}"
    )


def _category_from_text(user_message: str) -> Optional[str]:
    normalized = normalize_text(user_message)
    if any(token in normalized for token in FAMILY_CUES):
        return "family"
    if any(token in normalized for token in SOCIAL_CUES):
        return "friend"
    if any(token in normalized for token in WORK_CUES):
        return "work"
    return None


def _normalize_plan(raw: Dict[str, Any], scope: str, user_message: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not isinstance(raw, dict):
        return None

    plan: Dict[str, Any] = {
        "intent": raw.get("intent") if raw.get("intent") in ALLOWED_INTENTS else None,
        "category": raw.get("category") if raw.get("category") in ALLOWED_CATEGORIES else None,
        "profile": raw.get("profile") if raw.get("profile") in ALLOWED_PROFILES else None,
        "duration_minutes": None,
        "day_offsets": [],
        "strict_day": bool(raw.get("strict_day")),
        "contact_name": compact_name(raw.get("contact_name") or "") or None,
        "assistant_message": (raw.get("assistant_message") or "").strip() or None,
        "confidence": 0.0,
        "source": "llm",
    }

    try:
        duration = int(raw.get("duration_minutes"))
        if 15 <= duration <= 240:
            plan["duration_minutes"] = duration
    except Exception:
        plan["duration_minutes"] = None

    day_offsets: List[int] = []
    for value in raw.get("day_offsets") or []:
        try:
            offset = int(value)
        except Exception:
            continue
        if 0 <= offset <= 21 and offset not in day_offsets:
            day_offsets.append(offset)
    plan["day_offsets"] = day_offsets[:7]

    try:
        plan["confidence"] = round(float(raw.get("confidence") or 0.0), 3)
    except Exception:
        plan["confidence"] = 0.0

    defaults = INTENT_DEFAULTS.get(plan["intent"] or "", {})
    if defaults and not plan["category"]:
        plan["category"] = defaults.get("category")
    if defaults and not plan["profile"]:
        plan["profile"] = defaults.get("profile")
    if defaults and not plan["duration_minutes"]:
        default_duration = defaults.get("duration_minutes")
        if isinstance(default_duration, int):
            plan["duration_minutes"] = default_duration

    explicit_category = _category_from_text(user_message)
    if explicit_category == "family":
        plan["category"] = "family"
        plan["intent"] = plan["intent"] or "family_plan"
    elif explicit_category == "friend" and plan.get("category") not in {"family", "work"}:
        plan["category"] = "friend"
        plan["intent"] = plan["intent"] or "friend_meetup"
    elif explicit_category == "work" and plan.get("category") not in {"family", "friend"}:
        plan["category"] = "work"
        plan["intent"] = plan["intent"] or "meeting"

    if not plan["profile"]:
        if plan["category"] == "friend":
            plan["profile"] = "social"
        elif plan["category"] == "family":
            plan["profile"] = "family"
        else:
            plan["profile"] = "work"

    explicit_duration = explicit_duration_minutes_from_text(user_message)
    if explicit_duration and not plan["duration_minutes"]:
        plan["duration_minutes"] = explicit_duration

    context_now = context.get("now")
    parsed_now = datetime.fromisoformat(str(context_now).replace("Z", "+00:00")) if context_now else datetime.now()
    fallback_offsets, fallback_strict = explicit_day_offsets_from_text(user_message, now=parsed_now)
    if not plan["day_offsets"] and fallback_offsets:
        plan["day_offsets"] = fallback_offsets
    if not plan["strict_day"] and fallback_strict:
        plan["strict_day"] = True

    if not plan["intent"] and plan["category"] == "work":
        plan["intent"] = "meeting"
    elif not plan["intent"] and plan["category"] == "friend":
        plan["intent"] = "friend_meetup"
    elif not plan["intent"] and plan["category"] == "family":
        plan["intent"] = "family_plan"

    if not any([plan["intent"], plan["day_offsets"], plan["contact_name"], plan["assistant_message"], plan["duration_minutes"]]):
        return None

    return plan


def plan_message(scope: str, user_message: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    raw = generate_json(_system_prompt(), _user_prompt(scope, user_message, context))
    plan = _normalize_plan(raw or {}, scope=scope, user_message=user_message, context=context)
    if not plan:
        return None
    plan["_provider"] = f"{CONFIG.backend}:{CONFIG.model}" if CONFIG.enabled and CONFIG.model else None
    return plan


def llm_plan(context: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not context:
        return None
    plan = context.get("_llm_plan")
    return plan if isinstance(plan, dict) else None


def planned_intent(context: Optional[Dict[str, Any]]) -> Optional[str]:
    plan = llm_plan(context)
    return (plan or {}).get("intent") or None


def planned_duration_minutes(context: Optional[Dict[str, Any]]) -> Optional[int]:
    plan = llm_plan(context)
    value = (plan or {}).get("duration_minutes")
    return value if isinstance(value, int) else None


def planned_day_offsets(context: Optional[Dict[str, Any]]) -> List[int]:
    plan = llm_plan(context)
    values = (plan or {}).get("day_offsets") or []
    return [value for value in values if isinstance(value, int)]


def planned_strict_day(context: Optional[Dict[str, Any]]) -> bool:
    plan = llm_plan(context)
    return bool((plan or {}).get("strict_day"))


def planned_contact_name(context: Optional[Dict[str, Any]]) -> Optional[str]:
    plan = llm_plan(context)
    value = (plan or {}).get("contact_name")
    return value if value else None


def planned_assistant_message(context: Optional[Dict[str, Any]]) -> Optional[str]:
    plan = llm_plan(context)
    value = (plan or {}).get("assistant_message")
    return value if value else None


def planned_provider(context: Optional[Dict[str, Any]]) -> Optional[str]:
    plan = llm_plan(context)
    value = (plan or {}).get("_provider")
    return value if value else None


def current_llm_health() -> Dict[str, Any]:
    return health_status()
