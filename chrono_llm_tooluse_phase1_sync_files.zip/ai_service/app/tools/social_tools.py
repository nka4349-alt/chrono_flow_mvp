from __future__ import annotations

from typing import Any, Dict, List, Optional
import unicodedata


SOCIAL_HINTS = [
    "友達", "友人", "遊び", "遊ぶ", "遊びに行く", "出かけ", "出掛け", "お出かけ", "おでかけ",
    "旅行", "ドライブ", "会う", "会いたい", "ご飯", "ごはん", "食事", "ランチ", "ディナー", "飲み",
]


def normalize_text(text: str) -> str:
    return unicodedata.normalize("NFKC", (text or "")).strip().lower()


def _contact_rows(context: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for contact in context.get("contacts") or []:
        if isinstance(contact, dict) and (contact.get("display_name") or "").strip():
            rows.append(contact)
    return rows


def _friend_rows(context: Dict[str, Any]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for friend in context.get("friends") or []:
        if isinstance(friend, dict) and (friend.get("name") or friend.get("display_name") or "").strip():
            rows.append(friend)
    return rows


def _make_pseudo_contact(friend: Dict[str, Any]) -> Dict[str, Any]:
    display_name = (friend.get("name") or friend.get("display_name") or "").strip()
    return {
        "id": friend.get("id"),
        "display_name": display_name,
        "relation_type": "friend",
        "timezone": friend.get("timezone") or "Asia/Tokyo",
        "preferred_duration_minutes": 90,
        "availability_profiles": [],
        "linked_user_id": friend.get("id"),
        "email": friend.get("email"),
        "source": "friend_list",
    }


def resolve_entities(text: str, context: Dict[str, Any], planned_contact_name: Optional[str] = None) -> Dict[str, Any]:
    normalized = normalize_text(text)
    planned_name = normalize_text(planned_contact_name or "")

    exact_contact = None
    partial_contact = None
    exact_friend = None
    partial_friend = None

    for contact in _contact_rows(context):
        name = normalize_text(contact.get("display_name") or "")
        if not name:
            continue
        if planned_name and name == planned_name:
            exact_contact = contact
            break
        if name in normalized:
            exact_contact = contact
            break
        if planned_name and planned_name in name and partial_contact is None:
            partial_contact = contact

    if exact_contact is None:
        for friend in _friend_rows(context):
            name = normalize_text(friend.get("name") or friend.get("display_name") or "")
            if not name:
                continue
            if planned_name and name == planned_name:
                exact_friend = friend
                break
            if name in normalized:
                exact_friend = friend
                break
            if planned_name and planned_name in name and partial_friend is None:
                partial_friend = friend

    resolved_contact = exact_contact or partial_contact
    resolved_friend = None
    if resolved_contact is None:
        resolved_friend = exact_friend or partial_friend
        if resolved_friend is not None:
            resolved_contact = _make_pseudo_contact(resolved_friend)

    social_signal = any(token in normalized for token in [normalize_text(value) for value in SOCIAL_HINTS])

    return {
        "resolved_contact": resolved_contact,
        "resolved_contact_name": (resolved_contact or {}).get("display_name") if resolved_contact else None,
        "matched_from": "contacts" if exact_contact or partial_contact else "friends" if resolved_friend else None,
        "social_signal": social_signal or bool(resolved_contact),
        "friend_candidates": [
            (friend.get("name") or friend.get("display_name") or "").strip()
            for friend in _friend_rows(context)[:12]
            if (friend.get("name") or friend.get("display_name") or "").strip()
        ],
    }
