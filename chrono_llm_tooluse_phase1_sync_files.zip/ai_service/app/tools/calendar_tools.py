from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional


def _parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except Exception:
        return None


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def extract_date_constraints(now: datetime, planned_day_offsets: List[int], planned_strict_day: bool) -> Dict[str, Any]:
    offsets: List[int] = []
    for value in planned_day_offsets or []:
        try:
            offset = int(value)
        except Exception:
            continue
        if 0 <= offset <= 21 and offset not in offsets:
            offsets.append(offset)

    target_dates = [
        (now + timedelta(days=offset)).date().isoformat()
        for offset in offsets[:7]
    ]

    return {
        "day_offsets": offsets[:7],
        "strict_day": bool(planned_strict_day),
        "target_dates": target_dates,
    }


def summarize_calendar(context: Dict[str, Any], now: datetime, day_offsets: List[int], strict_day: bool, limit_days: int = 4) -> Dict[str, Any]:
    events = [event for event in (context.get("personal_events") or []) if isinstance(event, dict)]
    normalized_offsets = []
    for value in day_offsets or []:
        try:
            offset = int(value)
        except Exception:
            continue
        if 0 <= offset <= 21 and offset not in normalized_offsets:
            normalized_offsets.append(offset)

    if not normalized_offsets:
        normalized_offsets = list(range(0, limit_days))

    days: List[Dict[str, Any]] = []
    for offset in normalized_offsets[:limit_days]:
        day_start = (now + timedelta(days=offset)).replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_start + timedelta(days=1)
        busy_minutes = 0
        matches: List[Dict[str, Any]] = []
        for event in events:
            start_at = _parse_iso(event.get("start_at"))
            end_at = _parse_iso(event.get("end_at"))
            if not start_at or not end_at:
                continue
            if end_at <= day_start or start_at >= day_end:
                continue
            clipped_start = max(start_at, day_start)
            clipped_end = min(end_at, day_end)
            busy_minutes += max(0, int((clipped_end - clipped_start).total_seconds() // 60))
            matches.append(
                {
                    "title": event.get("title"),
                    "start_at": start_at.isoformat(),
                    "end_at": end_at.isoformat(),
                    "all_day": bool(event.get("all_day")),
                }
            )

        days.append(
            {
                "offset": offset,
                "date": day_start.date().isoformat(),
                "event_count": len(matches),
                "busy_minutes": busy_minutes,
                "events": matches[:6],
            }
        )

    total_busy = sum(_safe_int(day.get("busy_minutes")) for day in days)
    return {
        "strict_day": bool(strict_day),
        "evaluated_days": days,
        "total_busy_minutes": total_busy,
    }
